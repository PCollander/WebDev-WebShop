var http = require('http');
fs = require('fs');

var server = http.createServer(function (req, res) {
    const body = '';

        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end(JSON.stringify(req.headers));

});

server.listen(3000, '127.0.0.1');
