var http = require('http');

var server = http.createServer(function (req, res) {

        res.writeHead(200, { 'Content-type': 'text/plain' });

        req.on('data', (chunk) => {
            res.write(chunk);
        });

        req.on('end', function () {
            res.end();
        });

});

server.listen(3000, '127.0.0.1');

