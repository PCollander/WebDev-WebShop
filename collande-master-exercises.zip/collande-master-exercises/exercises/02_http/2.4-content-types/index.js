var http = require('http')
const fs = require('fs');

var server = http.createServer(function (req, res) {

    const accept = req.headers['accept'];

    if (accept == 'application/json') {
        fs.readFile('data.json', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': accept });
            res.write(data);
            res.end();
        });
    } else if ((accept == 'application/xml,text/xml') || (accept == 'application/xml') || (accept == 'text/xml')) {
        fs.readFile('data.xml', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': accept });
            res.write(data);
            res.end();
        });
    } else if ((accept == 'text/plain') || (accept == '*/*')) {
        fs.readFile('data.txt', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.write(data);
            res.end();
        });
    } else {
        res.statusCode = 406;
        res.statusMessage = 'Content type not available';
        res.end();
    };
});

server.listen(3000, '127.0.0.1');


