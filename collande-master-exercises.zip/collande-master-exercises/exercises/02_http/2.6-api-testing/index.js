var http = require('http')
const fs = require('fs');

var server = http.createServer(function (req, res) {

    const url = req.url;

    if (url == '/classical') {
        fs.readFile('homer.html', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });
    } else if (url == '/modern') {
        fs.readFile('bradbury.html', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });
    } else if (url == '/') {
        fs.readFile('index.html', "utf-8", (err, data) => {
            if (err) throw err;
            res.writeHead(200, { 'Content-Type': 'text/html' });
            res.write(data);
            res.end();
        });
    } else {
        res.statusCode = 404;
        res.statusMessage = 'Requested content not found';
        res.end();
    };
});

module.exports = server;
server.listen(3000, '127.0.0.1');