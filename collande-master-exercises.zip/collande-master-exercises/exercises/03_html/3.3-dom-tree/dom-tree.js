// 1
const naviElement = document.querySelector(".navi");
naviElement.classList.add("list");
const node = document.createElement("li");
naviElement.appendChild(node);

// 2
const lastElem = naviElement.lastElementChild;
const newLink = document.createElement("a");
newLink.innerText = 'Localhost';
newLink.href = 'http://localhost:3000/';
lastElem.appendChild(newLink);
  
// 3
const newList = document.querySelector("#ordered");
const node1 = document.createElement("li");
node1.innerText = 'Item 0'
newList.insertBefore(node1, newList.childNodes[0]);

// 4

const todoElement = document.querySelector("#todo");
todoElement.classList.remove("navi");

// 5
var itemToRemove = document.getElementById("todo");
itemToRemove.removeChild(itemToRemove.childNodes[3]);
