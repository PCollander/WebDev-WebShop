const DecButton = document.querySelector("#decrement")
DecButton.addEventListener("click", function () {
    const Count = document.querySelector("#counter");
    var counter = Number.parseInt(Count.textContent, 10);
    console.log(Count.textContent);
    console.log(counter);
    if (counter > -5) {
        counter -= 1;
    } else {
        counter = 5;
    };
    Count.innerText = counter;
});

const IncButton = document.querySelector("#increment")
IncButton.addEventListener("click", function () {
    const Count = document.querySelector("#counter");
    var counter = Number.parseInt(Count.textContent, 10);
    if (counter < 5) {
        counter += 1;
    } else {
        counter = -5;
    };
    Count.innerText = counter;
});

const ResetButton = document.querySelector("#reset")
ResetButton.addEventListener("click", function () {
    const Count = document.querySelector("#counter");
    var counter = Number.parseInt(Count.textContent, 10);
    counter = 0;
    Count.innerText = counter;
});
