document.querySelector("#submit").addEventListener("click", function (event) {
    event.preventDefault()
    // save form values
    const Name = document.querySelector("#input-name").value;
    const Email = document.querySelector("#input-email").value;
    const Page = document.querySelector("#input-homepage").value;

    // get template and clone it
    const Template = document.querySelector("#contact-template");
    const TemplateClone = Template.content.cloneNode(true);


    // update values to template clone
    TemplateClone.querySelector('h2').innerText = Name;
    TemplateClone.querySelector('.email').innerText = Email;
    TemplateClone.querySelector('.homepage').querySelector('a').href = Page
    TemplateClone.querySelector('.homepage').querySelector('a').innerText = Page
    TemplateClone.id = "contacts";

    // add contact template clone to contacts
    const ContactsElement = document.querySelector("#contacts");
    ContactsElement.appendChild(TemplateClone);

    console.log(Template);
    console.log(TemplateClone);

    document.getElementById("form").reset();
});
