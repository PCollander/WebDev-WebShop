function countListElements() {

    var liElems = [];
    liElems = document.getElementsByTagName("li");


    for (i = 0; i < liElems.length; ++i) {
        var sublistElementCount = liElems[i].getElementsByTagName("li").length;
        if (liElems[i].getElementsByTagName("ul").length != 0) {

            var x = liElems[i].firstChild.textContent;
            liElems[i].firstChild.textContent = x + "(" + sublistElementCount + ")";
            
        }
    }
}


countListElements();