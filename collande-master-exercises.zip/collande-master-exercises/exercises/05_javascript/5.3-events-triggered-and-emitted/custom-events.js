document.getElementById("roll-button").addEventListener("click", () => {
    rollDice();
});

function updateDice(diceValue) {
    var diceIds = {
        1: "ones",
        2: "twos",
        3: "threes",
        4: "fours",
        5: "fives",
        6: "sixes",
    };

    var elemToSet = document.getElementById(diceIds[diceValue]).querySelector("p")
        .innerHTML; // Selects element by the id property based on the dice roll value

    if (elemToSet === "-") {
        elemToSet = 0; // Set value to 0 if there are no previous dice rolls for the counter
    }
    document.getElementById(diceIds[diceValue]).querySelector("p").innerHTML =
        parseInt(elemToSet) + 1; // Counter value is incremented by one, target based on the dice roll value

    var rollButtonElem = document.getElementById("roll-button");
    var currenTemplateElem = document.getElementById("template" + diceValue); // Selects the template to be set based on the dice roll value

    rollButtonElem.innerHTML = currenTemplateElem.innerHTML; // Sets the template accordingly with each throw to represent the dice roll value

    var totalRollsElem = document.getElementById("totals").querySelector("span");
    totalRollsElem.innerHTML = parseInt(totalRollsElem.innerHTML) + 1; // Number of total rolls incremented by one
}


document.addEventListener("rollDice", function (event) {
    const diceValue = event.detail.value; 
    updateDice(diceValue);

});