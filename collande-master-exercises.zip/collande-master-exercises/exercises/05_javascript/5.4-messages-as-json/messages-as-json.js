document.addEventListener("userDataReady", function (event) {
    const textToParse = event.detail.jsonText;
    var parsedText = JSON.parse(textToParse);

    const Template = document.querySelector("#user-card-template");
    let TemplateClone = Template.content.cloneNode(true);

    for (let i = 0; i < Object.keys(parsedText).length; ++i) {
        TemplateClone = Template.content.cloneNode(true);
        TemplateClone.querySelector("h1").innerText =
            parsedText[i].firstName + " " + parsedText[i].lastName;
        TemplateClone.querySelector(".email").innerText = parsedText[i].email;
        TemplateClone.querySelector(".phone").querySelector("span").innerText =
            parsedText[i].phoneNumber;

        var addressChildren = TemplateClone.querySelector(
            ".address"
        ).querySelectorAll("p");
        addressChildren[0].innerText = parsedText[i].address.streetAddress;
        addressChildren[1].innerText =
            parsedText[i].address.zipCode + " " + parsedText[i].address.city;
        addressChildren[2].innerText = parsedText[i].address.country;

        TemplateClone.querySelector(".homepage").querySelector("a").href =
            parsedText[i].homepage;
        TemplateClone.querySelector(".homepage").querySelector("a").innerText =
            parsedText[i].homepage;
        TemplateClone.querySelector(".card").querySelector("img").src =
            parsedText[i].avatar;
        TemplateClone.querySelector(".card").querySelector("img").alt =
            parsedText[i].firstName + " " + parsedText[i].lastName;

        TemplateClone.id = "contacts";
        const ContactsElement = document.querySelector("#contacts");
        ContactsElement.appendChild(TemplateClone);
    }
});

fetchUserData();
