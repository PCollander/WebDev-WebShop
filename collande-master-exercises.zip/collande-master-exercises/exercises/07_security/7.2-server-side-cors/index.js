const http = require("http");
const port = 3000;

http
    .createServer((request, response) => {
        const headers = {
            "Access-Control-Allow-Origin": "*"
        };

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-control-max-age", 7200);
        response.setHeader("Access-Control-Allow-Headers",
            "Origin, X-Requested-With, Content-Type, Accept, Authorization, Cache-control"
        );
        response.setHeader("Cache-control", "public, max-age = 7200");
        response.setHeader("Access-Control-Allow-Methods",
            "get, post, head"
        );

        if (!!!request.headers["origin"]) {
            response.statusCode = 400;
            response.write("Origin header not in the request");
        } else {
            if (request.method === "HEAD") {
                response.statusCode = 200;
            } else if (request.method === "GET") {
                response.statusCode = 200;
                response.write("I was requested using CORS!");
            } else if (request.method === "POST") {
                response.statusCode = 200;
                response.write("I was requested using CORS!");
            } else {
                response.statusCode = 405;
                response.write("Request used a HTTP method which is not allowed.");
            }
        }
        response.end();
        // TODO: handle HEAD HTTP method,
        // remember to add CORS headers to response

        // TODO: handle GET and POST HTTP methods,
        // remember to add CORS headers to response

        // TODO: handle HTTP methods that are not allowed,
        // remember to add CORS headers to response
    })
    .listen(port);
