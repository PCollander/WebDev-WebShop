document.addEventListener('DOMContentLoaded', (event) => {
    let scr_span = document.querySelector("#script_span");
    scr_span.textContent = 'OH, YES WE SHALL!';
})