# Group

Member1: Valtteri Virtanen, valtteri.v.virtanen@tuni.fi, 98522,
resposible for: TODO, short description of duties

Member2: name, email, student ID,
resposible for: TODO, short description of duties

# WebDev1 coursework assignment

A web shop with vanilla HTML, CSS.

### The project structure

```
.
├── index.js                --> TODO
├── package.json            --> TODO
├── routes.js               --> TODO
├── auth                    --> TODO
│   └──  auth.js            --> TODO
├── controllers             --> TODO
│   ├──  ...                -->   ...
│   └── users.js            --> controller for user
├── models                  -->
│                               TODO
├── public                  -->
│   ├── img                 -->
│   ├── js                  -->
│   └── css                 -->
├── utils                   --> TODO
│   ├──                     --> TODO
│   └──                     --> TODO
└── test                    --> tests
│   ├── auth                --> TODO
│   ├── controllers         --> TODO
└── └── own                 --> TODO


```

TODO: describe added files here and give them short descriptions

## The architecture

TODO: describe the system, important buzzwords include MVC and REST.
UML diagrams would be highly appreciated.

## Tests and documentation

TODO: Links to at least 10 of your group's GitLab issues, and their associated Mocha tests and test files.

## Security concerns

TODO: list the security threats represented in the course slides.
Document how your application protects against the threats.
You are also free to add more security threats + protection here, if you will.
