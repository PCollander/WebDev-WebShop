docker stop wd1-mongodb && docker rm wd1-mongodb
