docker run --name wd1-mongodb -v wd1-mongodb:/data/db -p27017:27017 -d mongo:4.4-bionic
